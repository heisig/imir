﻿Binary_Search


Getting Started


Step 1.
Execute parser.exe and point it to the data. Creating the inverted may - depending on the file size - take up to 15 minutes. Alternatively you can use the provided “test.ttl” which has around 8000 document entries.
If successful you should now see a file called output.txt in your current folder. 


Step 2.
Execute search.exe. Enter your query. It should be valid according to the 
following query rules:


1) Single term must be a single word or a phrase. For example:
        Your Query: südafrika
        Your Query: südafrika und mosambik
        


2) Separate the parts of your compound term with " AND ", " OR ", " NOT ".  
     Pay attention to whitespaces between part-terms and operators. It should look like:
        Your Query: südafrika AND mosambik
        Your Query: NOT mosambik OR südafrika
        Your Query: südafrika und mosambic AND NOT nordafrika


3) Invalid inputs and senseless cases like “Your Query: OR südafrika” are not searchable


The answer returns found resources, total number of found resources and total number of occurrences of the term. In case of compound terms  the total number of occurrences represents the summation of total numbers of occurrences of each subterm.




Implemented with Python 3.5.2 by Hung Tran Duc, Franz-Wilhelm Schumann, 
Philipp Heisig, Elizaveta Ragozina as part of exercise "Interactive Multimedia 
Information Retrieval "